<section class="content coberturas-container">

    <?php
        include get_template_directory().'/templates/list-coberturas.php';
    ?>

    <a href="<?= $menu_coberturas ?>" class="btn btn-primary btn-centerPage">
        Ver Todos
    </a>

</section>
