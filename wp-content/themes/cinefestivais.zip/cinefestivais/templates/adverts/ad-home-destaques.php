<?php
    if (function_exists('adinserter')) {
        echo "<section class='advertisingContainer'>";
            echo adinserter(1);
        echo "</section>";
    }

