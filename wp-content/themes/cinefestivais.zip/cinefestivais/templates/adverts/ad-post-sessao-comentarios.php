<?php
    if (function_exists('adinserter')) {
        echo "<section class='advertisingContainer'>";
            echo adinserter(5);
        echo "</section>";
    }

