<?php
    if (function_exists('adinserter')) {
        echo "<section class='advertisingContainer'>";
            echo adinserter(3);
        echo "</section>";
    }

