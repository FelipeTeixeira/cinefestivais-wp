<?php
    if (function_exists('adinserter')) {
        echo "<section class='advertisingContainer'>";
            echo adinserter(2);
        echo "</section>";
    }

