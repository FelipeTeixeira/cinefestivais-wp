<?php
    if (function_exists('adinserter')) {
        echo "<section class='advertisingContainer p-margin-bottom-62'>";
            echo adinserter(4);
        echo "</section>";
    }

