<section class="content">
    <h2 class="content-title">Siga no cine festivais</h2>

    <div class="cards">
        <div class="card">
            <img src="https://picsum.photos/id/3/300/200" alt="" class="card-picture">
            <div class="card-label">
                <span class="card-label__text">Entrevistas</span>
            </div>
            <p class="card-text">"Na Paraíba Anoitece": Uma conversa com Ramon Porto Mota</p>
        </div>
        <div class="card">
            <img src="https://picsum.photos/id/3/300/200" alt="" class="card-picture">
            <div class="card-label">
                <span class="card-label__text">Entrevistas</span>
            </div>
            <p class="card-text">"Na Paraíba Anoitece": Uma conversa com Ramon Porto Mota</p>
        </div>
        <div class="card">
            <img src="https://picsum.photos/id/3/300/200" alt="" class="card-picture">
            <div class="card-label">
                <span class="card-label__text">Entrevistas</span>
            </div>
            <p class="card-text">"Na Paraíba Anoitece": Uma conversa com Ramon Porto Mota</p>
        </div>

        <div class="card">
            <img src="https://picsum.photos/id/3/300/200" alt="" class="card-picture">
            <div class="card-label">
                <span class="card-label__text">Entrevistas</span>
            </div>
            <p class="card-text">"Na Paraíba Anoitece": Uma conversa com Ramon Porto Mota</p>
        </div>
    </div>

    <div class="is-center">
        <button type="button" class="btn btn-primary btn-small">Ver Mais</button>
    </div>

</section>