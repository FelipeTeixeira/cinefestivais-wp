<section class="newsletter">
    <h3 class="newsletter-title">
        Newsletter
    </h3>
    <p class="newsletter-text">
        Receba as coberturas do Cine Festivais na sua caixa de entrada
    </p>
    <button type="button" class="btn btn-default">Assinar</button>
</section>