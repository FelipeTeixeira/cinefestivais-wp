<section class="newsletter">
    <h3 class="newsletter-title">
        Newsletter
    </h3>
    <p class="newsletter-text">
        Receba as novidades do cine festivais na sua caixa de entrada
    </p>
    <a href="https://mailchi.mp/aedbb5482c46/cinefestivais" target="_blank" class="btn btn-default">Assinar</a>
</section>