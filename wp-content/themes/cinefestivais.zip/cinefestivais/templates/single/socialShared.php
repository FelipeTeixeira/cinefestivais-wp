<div class="socialShared-container singlePg-container">
    <ul class="socialShared">
        <li>
            <a href="" class="socialShared-item">
                <svg class="icon icon-bubble">
                    <use xlink:href="#icon-bubble"></use>
                </svg>
            </a>
        </li>

        <li class="socialShared-divisor">
            <a href="" class="socialShared-item socialShared-item--shared">
                <svg class="icon icon-share-alt">
                    <use xlink:href="#icon-share-alt"></use>
                </svg>
                <span class="socialShared-item--shared-text">
                    COMPARTILHE
                </span>
            </a>
        </li>

        <li>
            <a href="" class="socialShared-item socialShared-item-circle">
                <svg class="icon icon-facebook">
                    <use xlink:href="#icon-facebook"></use>
                </svg>
            </a>
        </li>

        <li>
            <a href="" class="socialShared-item socialShared-item-circle">
                <svg class="icon icon-twitter">
                    <use xlink:href="#icon-twitter"></use>
                </svg>
            </a>
        </li>

        <li>
            <a href="" class="socialShared-item socialShared-item-circle">
                <svg class="icon icon-envelope">
                    <use xlink:href="#icon-envelope"></use>
                </svg>
            </a>
        </li>
        
        <li>
            <a href="" class="socialShared-item socialShared-item-circle">
                <svg class="icon icon-whatsapp">
                    <use xlink:href="#icon-whatsapp"></use>
                </svg>
            </a>
        </li>
    </ul>
</div>