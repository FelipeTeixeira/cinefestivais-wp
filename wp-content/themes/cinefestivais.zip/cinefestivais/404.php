<?php
	require_once('header.php');

	// TEMPLATE ERROR
	require_once('templates/error.php');

	get_footer(); 
