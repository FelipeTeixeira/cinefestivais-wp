<?php
	get_header();

	// TEMPLATE ERROR
	require_once('templates/error.php');

	get_footer(); 
